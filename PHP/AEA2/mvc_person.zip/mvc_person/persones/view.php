<?php

class view {
  
  private $diccionari = array (
    'subtitle' => array ('inici' => 'Buscar persona', // titles for each view
                         'view1' => 'Mostrar dades nom i edat',
                         'view2' => 'Mostrar dades nom i alcada',
                         'search' => 'Buscar persona',
                         'view_insert' => 'Insertar nova persona',
                         'view_update' => 'Actualitzar persona',
                         'view_delete' => 'Eliminar persona'),
						 'form' => array ('form_select' => array('nom'),
										  'form_insert' => array('nom','edat','alcada'),
										  'form_update' => array('nom','edat','alcada'),
										  'form_delete' => array('nom')),
    'capçalera' => array ('view1' => array('nom','edat'), // table headers for each view
                         'view2' => array('nom','alcada'),
						 'view_select' => array('nom','edat','alcada')));
  

public function retornar_vista ($vista, $dades=array(), $message="Dades de l'usuari") {
	
	// the main template is read (menu, message and the main body (a form or select result)
        // read entire file into a string
	$html = file_get_contents(__DIR__ . '/../site_media/html/persones_template.html');
        //print_r ($html);
	
	// subtitle of the page is writen 
	$html = str_replace('{subtitle}', $this->diccionari['subtitle'][$vista], $html);
        //print_r($html);
	
	// message passed by controller is writen 
	$html = str_replace('{message}', $message, $html);
        //print_r($html);
	
	// the HTML table with the select result is built 
	if ($vista=='view1' || $vista=='view2' || ($vista=='search' && count($dades)>0)) {
		
		// the view template is read and its contents is included in the main template
		$view = file_get_contents(__DIR__ . '/../site_media/html/view_template.html');
		$html = str_replace ('{main}', $view, $html);
		
		// the table header is built and writen on the template
		$capçalera = $this->buildHeader ($vista);
		$html = str_replace('{capçalera}', $capçalera,$html);
		
		// the table contents is built and writen on the template
		$contingut = $this->buildContents ($dades);
		$html = str_replace('{contingut}', $contingut, $html);
	}
	
	// Build form for search
	if ($vista=='inici' || ($vista=='search' && count($dades)==0) || ($vista=='view_select' && count($dades)==0) || $vista=='view_insert' || $vista=='view_update' || $vista=='view_delete') {
		if ($vista == 'search' || $vista == 'inici') {
			$form_type = 'form_select';
			$action = 'search';
		} elseif ($vista == 'view_insert') {
			$form_type = 'form_insert';
			$action = 'insert';
		} elseif ($vista == 'view_update') {
			$form_type = 'form_update';
			$action = 'update';
		} elseif ($vista == 'view_delete') {
			$form_type = 'form_delete';
			$action = 'delete';
		} else {
			$form_type = $vista;
			$action = 'search';
		}
		$formulari = $this->buildForm($form_type, $action);
		$html = str_replace('{main}', $formulari, $html);
	}



	print $html;
} 


private function buildHeader ($vista) {
	$str = "";
	foreach ($this->diccionari['capçalera'][$vista] as $value) 
		$str .= "<th>" . $value . "</th>";
	return $str;
} 


private function buildContents ($dades, $haEsborrat = false) {
	$str = "";
	for ($i=0; $i<count($dades); $i++) {
		$str .= "<tr>";
		foreach ($dades[$i] as $value) 
			$str .= "<td>$value</td>";
		$str .= "</tr>";
	}
	return $str;
}


private function buildForm ($vista, $action = 'search') {
	$buttonText = '';
	switch($action) {
		case 'insert':
			$buttonText = 'Insertar';
			break;
		case 'update':
			$buttonText = 'Actualitzar';
			break;
		case 'delete':
			$buttonText = 'Eliminar';
			break;
		default:
			$buttonText = 'Buscar';
	}
	
	$str = "<form method='POST' action='index.php?action=$action'>";
	foreach ($this->diccionari['form'][$vista] as $value) {
	
		$str .= "<div> $value </div>";
		$str .= "<div><input type='text' name='$value' id='$value' required></div>";	
	}
	$str .= "<div><input type='submit' value='$buttonText'></div>";	
	$str .= "</form>";
	return $str;
	}

}
?>