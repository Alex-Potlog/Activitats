<?php

// magic constant
require_once (__DIR__ . "/../core/DBAbstractModel.php");

class persones extends DBAbstractModel {
  
  private $id;
  private $nom;
  private $edat;
  private $alcada;

  public $message;
  
  function __construct() {
    $this->db_name = "patromvc";
    }
  
  function __toString() {
    echo "entro string <br>";
    return "(" . $this->id . ", " . $this->nom . ", " . $this->edat . ", " .  
      $this->alcada . ")";
  }
  
  function __destruct() {

  }
  
  //select dels camps passats de tots els registres
  //stored in $rows property
  public function selectAll($fields=array()) {
    
    $this->query="SELECT ";
    $firstField = true;
    for ($i=0; $i<count($fields); $i++) {
      if ($firstField) {
        $this->query .= $fields[$i];
        $firstField=false;
      }
      else $this->query .= ", " . $fields[$i];
    }
    $this->query .= " FROM persones";
    $this->get_results_from_query();
    return $this->rows;
    
  }
  
  public function select($nom="") {
    if (empty($nom)) {
      $this->query = "SELECT nom, edat, alcada FROM persones;";
    } else {
      $sanitizedNom = addslashes($nom);
      $this->query = "SELECT nom, edat, alcada FROM persones WHERE nom = '" . $sanitizedNom . "';";
    }
    $this->get_results_from_query();
    return $this->rows;
  }
  
  
  public function insert($user_data = array()) {
    if (!empty($user_data['nom']) && !empty($user_data['edat']) && !empty($user_data['alcada'])) {
      $nom = addslashes($user_data['nom']);
      $edat = intval($user_data['edat']);
      $alcada = floatval($user_data['alcada']);
      
      $this->query = "INSERT INTO persones (nom, edat, alcada) VALUES ('$nom', $edat, $alcada)";
      $this->execute_single_query();
      $this->message = "Persona insertada correctament";
    } else {
      $this->message = "Error: Tots els camps són obligatoris";
    }
  }
  
  public function update ($userData = array()) {
    if (!empty($userData['nom']) && isset($userData['edat']) && isset($userData['alcada'])) {
      $nom = addslashes($userData['nom']);
      $edat = intval($userData['edat']);
      $alcada = floatval($userData['alcada']);
      
      $this->query = "UPDATE persones SET edat = $edat, alcada = $alcada WHERE nom = '$nom'";
      $this->execute_single_query();
      $this->message = "Persona actualitzada correctament";
    } else {
      $this->message = "Error: Tots els camps són obligatoris";
    }
  }
 
  public function delete ($nom="") {
    if (!empty($nom)) {
      $nom = addslashes($nom);
      $this->query = "DELETE FROM persones WHERE nom = '$nom'";
      $this->execute_single_query();
      $this->message = "Persona eliminada correctament";
    } else {
      $this->message = "Error: El nom és obligatori";
    }
    return $this->select();
  }
 
    
}

?>
