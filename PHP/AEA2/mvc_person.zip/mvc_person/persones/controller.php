<?php

require_once 'model.php';
require_once 'view.php';

class controller {
  
  //rutes o esdeveniments possibles
  //view1: nom i edat
  //view2: nom i alçada
  private $peticions = array('view1', 'view2', 'search', 'insert', 'update', 'delete');
  
  public function handler () {
    
    // Què em demanen?
    $event = 'inici';
    
    // On som?
    $uri = $_SERVER['REQUEST_URI'];
    echo $uri;
 
    foreach ($this->peticions as $peticio) //Find the position of the first occurrence of a substring in a string
      if (strpos($uri,$peticio) == true)
        $event = $peticio;
          
    $per = new persones();
    
    $view = new view();
    
    switch ($event) {
        
        
        case 'view1':
          $dades = $per->selectAll(array("nom","edat"));
          $view->retornar_vista($event, $dades);
          break;
        
        case 'view2':
          $dades = $per->selectAll(array("nom","alcada"));
          $view->retornar_vista($event, $dades);
          break;

        case 'search':
          if (isset($_POST['nom']) && !empty($_POST['nom'])) {
            $dades = $per->select($_POST['nom']);
            $view->retornar_vista($event, $dades);
          } else {
            $view->retornar_vista($event, []);
          }
          break;
        
        case 'insert':
          if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $per->insert($_POST);
            $message = $per->message;
          } else {
            $message = "Introduir dades per insertar";
          }
          $view->retornar_vista('view_insert', [], $message);
          break;
        
        case 'update':
          if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $per->update($_POST);
            $message = $per->message;
          } else {
            $message = "Introduir dades per actualitzar";
          }
          $view->retornar_vista('view_update', [], $message);
          break;
        
        case 'delete':
          if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dades = $per->delete($_POST['nom']);
            $message = $per->message;
            $view->retornar_vista('view_delete', $dades, $message);
          } else {
            $message = "Introduir nom per eliminar";
            $view->retornar_vista('view_delete', [], $message);

          }
          break;
        
        case 'inici':
            $view->retornar_vista($event, []);

              
        }
      
  }

  
}





?>