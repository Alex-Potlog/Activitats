<?php

require_once "DBAbstractModel.php";
class Concerts extends DBAbstractModel{
    public function __construct() {
    }

    public function selectAll(): array | null {
        $this->query = "SELECT grup, ciutat, sala, data, hora FROM concerts;";
        $this->get_results_from_query();
        return $this->rows;
    }

    public function select(array $param = [], bool $betweenDates = false): array | null {
        $this->query = "SELECT grup, ciutat, sala, data, hora FROM concerts";
        if ($param != "" && !$betweenDates) {
            $nom = $param[0] ?? "";
            $this->query .= ' WHERE LOWER(grup) = LOWER("' . $nom . '");';
        } else if ($param != "" && $betweenDates) {
            $this->query .= " WHERE data BETWEEN '" . $param[0] . "' AND '" . $param[1] . "';";
        }
        $this->get_results_from_query();
        return $this->rows;
    }

    public function insert(array $params): array {
        if (isset($params["grup"]) && isset($params["ciutat"]) && isset($params["sala"]) && isset($params["data"]) && isset($params["hora"])){
            $this->query = 'INSERT INTO concerts (grup, ciutat, sala, data, hora) VALUES (
                "' . $params["grup"] . '", "' . $params["ciutat"] . '", "' . $params['sala'] . '", "'. $params['data'] . '", ' . $params['hora'] .'
            );';
        } else {
            echo "Falten paràmetres: ";
            print_r($_POST);
            print_r($params);
        }
        
        $this->execute_single_query(admin: true);
        return $this->selectAll();
    }

    public function update(array $params): array {
        if (isset($params["grup"]) && isset($params["ciutat"]) && isset($params["sala"]) && isset($params["data"]) && isset($params["hora"])){
            $this->query = 'UPDATE concerts
                            SET hora = ' . $params["hora"] . '
                            WHERE LOWER(grup) LIKE LOWER("' . $params["grup"] . '") 
                            AND ciutat LIKE LOWER("' . $params["ciutat"] . '")
                            AND sala LIKE LOWER("' . $params["sala"] . '")
                            AND data = "' . $params["data"] . '";'; 
            echo $this->query;
        } else {
            echo "Falten paràmetres: ";
            print_r($_POST);
            print_r($params);
        }      

        $this->execute_single_query(admin: true);
        return $this->selectAll();
    }
}