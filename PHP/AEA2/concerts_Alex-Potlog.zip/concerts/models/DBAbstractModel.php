<?php

abstract class DBAbstractModel  {
    private $connection;
    protected $query;
    private static $db_name = "concerts";

    private static $db_host = "localhost:3306";
    private static $db_user_admin = "admin_concert";
    private static $db_pass_admin = "admin";

    private static $db_user = 'client';
    private static $db_pass = 'client';
    protected $rows = [];

    private function openConnectionAdmin() {
        $this->connection = mysqli_connect(self::$db_host,self::$db_user_admin,self::$db_pass_admin, self::$db_name) or die("No s'ha pogut connectar");
    }

    private function closeConnection(): void {
        $this->connection = mysqli_close($this->connection);
    }

    private function openConnection() {
        $this->connection = mysqli_connect(self::$db_host, self::$db_user, self::$db_pass,self::$db_name, 3306) or die("No s'ha pogut connectar");
    }

    abstract protected function select(array $param = [], bool $betweenDates = false): array | null;
    abstract protected function insert(array $params): array;
    abstract protected function update(array $params): array;
    abstract protected function selectAll(): array | null;

    protected function execute_single_query(bool $admin) {
        $this->openConnection();
        $this->connection->query($this->query);
        $this->closeConnection();
    }

    protected function get_results_from_query() {
        $this->openConnection();
        $result = $this->connection->query($this->query);
        for ($i=0;$i<$result->num_rows;$i++)
            $this->rows[$i]=$result->fetch_assoc();
        $result->close();
        $this->closeConnection();
    }
}