<?php

class Vista {
    private $userViews = [
        "Inici" , "Mostrar concerts"
    ];

    private $adminViews = [
        "Inserir concert", "Modificar hora"
    ];

    private $currentViews;

    public function __construct(bool $isAdmin = false) {
        $this->currentViews = $isAdmin ? $this->adminViews : $this->userViews;
    }

    public function getView(string $view = "", array $dada = []) {
        switch ($this->currentViews) {
            case $this->userViews:
                return $this->getUserView($view, $dada);
            case $this->adminViews:
                return $this->getAdminView($view, $dada);
            default:
                return "No s'ha trobat la vista";
        }
    }

    private function getUserView(string $view, array $dada) {
        $html = file_get_contents(__DIR__ . "/templates/iniciUser.html");
        switch ($view) {
            case "inici":
                $html = str_replace("{{ buscador }}", "", $html);
                $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                return $html;
            case "cerca":
                $html = str_replace("{{ buscador }}",file_get_contents(__DIR__ . "/templates/form.html"), $html);
                $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                return $html;
            case "cercaData":
                $html = str_replace("{{ buscador }}",file_get_contents(__DIR__ . "/templates/formData.html"), $html);
                $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                return $html;
        }
    }

    private function getAdminView(string $view, array $dada) {
        $html = file_get_contents(__DIR__ . "/templates/iniciAdmin.html");
        switch ($view) {
            case "inici":
                $html = str_replace("{{ buscador }}", "", $html);
                $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                return $html;
            case "cerca":
                $html = str_replace("{{ buscador }}",file_get_contents(__DIR__ . "/templates/form.html"), $html);
                $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                return $html;
            case "cercaData":
                $html = str_replace("{{ buscador }}",file_get_contents(__DIR__ . "/templates/formData.html"), $html);
                $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                return $html;
            case "adminInsert":
            case "adminModify":
                if ($dada == []){
                    $html = str_replace("{{ buscador }}",file_get_contents(__DIR__ . "/templates/complexForms.html"), $html);
                    $html = str_replace("{{ accio }}", $view, $html);
                    $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                    $html = str_replace("{{ taula }}", "", $html);
                } else {
                    $html = str_replace("{{ buscador }}","", $html);
                    $html = str_replace("{{ vistes }}", implode(" ", $this->currentViews), $html);
                    $html = str_replace("{{ taula }}", $this->getTable($dada), $html);
                }
                return $html;
        }
    }

    private function getTable(array $dada){
        $resposta = file_get_contents(__DIR__ . "/templates/concerts.html");
        if (isset($dada) && is_array($dada)) {
            $temp = "";
            foreach ($dada as $key => $value) {
                $temp .= "<tr>";
                foreach ($value as $k => $v) {
                    $temp .= "<td>" . $v . "</td>";
                }
                $temp .= "</tr>";
            }
            $resposta = str_replace("{{ dades }}", $temp, $resposta);
        }
        return $resposta;
    }
}