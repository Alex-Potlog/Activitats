DROP DATABASE IF EXISTS concerts;
CREATE DATABASE concerts;
USE concerts;
CREATE TABLE concerts (
    id_concert int auto_increment primary key,
    grup text,
    ciutat text,
    sala text,
    data date,
    hora int
);
INSERT INTO concerts (grup, ciutat, sala, data, hora)
VALUES (
        "Arctic Monkeys",
        "Barcelona",
        "Montjuic",
        "2030-01-12",
        15
    ),
    (
        "Coldplay",
        "Mataro",
        "Foment Mataroni",
        "2026-01-12",
        22
    ),
    (
        "Good Bunny",
        "Madrid",
        "Puerta de la luna",
        "2010-01-12",
        11
    );