<?php
  error_reporting(-1);
  ini_set('display_errors','On');

  if (session_status() === PHP_SESSION_NONE) {
    session_start();
  }

  if (isset($_SESSION['admin'])) {
    require_once "controllers/controllerAdmin.php";
    $controller = new controllerAdmin();
  } else {
    require_once "controllers/controllerUser.php";
    $controller = new controllerUser();
  }

  $controller->handler();
