<?php

require_once __DIR__."/../models/Concerts.php";
require_once __DIR__."/../views/view.php";

class controllerUser {
    private $model;
    private $vista;

    public function __construct() {
        $this->model = new Concerts();
        $this->vista = new Vista();
    }

    public function handler(){
        if (isset($_GET["action"])) {
            $action = $_GET["action"];
            switch ($action) {
                case "inici":
                    $dades = $this->model->selectAll();
                    echo $this->vista->getView("inici", $dades);
                    break;
                case "cerca":
                    if (isset($_POST["grup"])){
                        $param[0] = $_POST["grup"];
                        $dades = $this->model->select($param);
                    } else {
                        $dades = $this->model->selectAll();
                    }
                    echo $this->vista->getView("cerca", $dades);
                    break;
                case "cercaData":
                    if (isset($_POST["dataPrimera"]) && isset($_POST["dataSegona"])){
                        $param[0] = $_POST["dataPrimera"];
                        $param[1] = $_POST["dataSegona"];
                        $dades = $this->model->select($param, true);
                    } else {
                        $dades = $this->model->selectAll();
                    }
                    echo $this->vista->getView("cercaData", $dades);
                    break;
                case "adminLogin":
                    if (session_status() === PHP_SESSION_NONE) {
                        session_start();
                    }
                    $_SESSION["admin"] = true;
                    header("Location: index.php");
                    exit;
            }
        } else {
            $dades = $this->model->selectAll();
            echo $this->vista->getView("inici", $dades);
        }
    }
}