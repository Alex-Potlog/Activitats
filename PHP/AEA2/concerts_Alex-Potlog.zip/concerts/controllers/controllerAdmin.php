<?php

require_once __DIR__."/../models/Concerts.php";
require_once __DIR__."/../views/view.php";

class ControllerAdmin {
    private $model;
    private $vista;

    public function __construct() {
        $this->model = new Concerts();
        $this->vista = new Vista(true);
    }

    public function handler(){
        if (isset($_GET["action"])) {
            $action = $_GET["action"];
            switch ($action) {
                case "inici":
                    $dades = $this->model->selectAll();
                    echo $this->vista->getView("inici", $dades);
                    break;
                case "cerca":
                    if (isset($_POST["grup"])){
                        $param[0] = $_POST["grup"];
                        $dades = $this->model->select($param);
                    } else {
                        $dades = $this->model->selectAll();
                    }
                    echo $this->vista->getView("cerca", $dades);
                    break;
                case "cercaData":
                    if (isset($_POST["dataPrimera"]) && isset($_POST["dataSegona"])){
                        $param[0] = $_POST["dataPrimera"];
                        $param[1] = $_POST["dataSegona"];
                        $dades = $this->model->select($param, true);
                    } else {
                        $dades = $this->model->selectAll();
                    }
                    echo $this->vista->getView("cercaData", $dades);
                    break;
                case "adminLogout":
                    if (session_status() === PHP_SESSION_NONE) {
                        session_start();
                    }
                    $_SESSION = [];
                    setcookie(session_name(), '');
                    session_destroy();  
                    header("Location: index.php");
                    exit;
                case "adminInsert":
                    if (!isset($_POST["grup"]) || !isset($_POST["ciutat"]) || !isset($_POST["sala"]) || !isset($_POST["data"]) || !isset($_POST["hora"])){
                        echo $this->vista->getView($action);
                    } else {
                        $params = ["grup" => $_POST["grup"], "ciutat" => $_POST["ciutat"], "sala" => $_POST["sala"], "data" => $_POST["data"], "hora" => $_POST["hora"]];
                        $dades = $this->model->insert($params);
                        echo $this->vista->getView($action, $dades);
                    }
                    break;
                case "adminModify":
                    if (!isset($_POST["grup"]) || !isset($_POST["ciutat"]) || !isset($_POST["sala"]) || !isset($_POST["data"]) || !isset($_POST["hora"])){
                        echo $this->vista->getView($action);
                    } else {
                        $params = ["grup" => $_POST["grup"], "ciutat" => $_POST["ciutat"], "sala" => $_POST["sala"], "data" => $_POST["data"], "hora" => $_POST["hora"]];
                        $dades = $this->model->update($params);
                        echo $this->vista->getView($action, $dades);
                    }
                    break;
                default:
                    $dades = $this->model->selectAll();
                    echo $this->vista->getView("inici", $dades);
                    break;
            }
        } else {
            $dades = $this->model->selectAll();
            echo $this->vista->getView("inici", $dades);
        }
    }
}