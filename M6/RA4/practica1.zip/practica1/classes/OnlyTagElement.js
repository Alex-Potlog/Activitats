import DomElement from "./DomElement.js";

export default class OnlyTagElement extends DomElement{
    constructor(tag, attributes = {}){ 
        super(tag, attributes);
    }
}