import DomElement from "./DomElement.js";

export default class CompoundElement extends DomElement {

    constructor(tag, attributes = {}){
        super(tag, attributes);
    }

    addChildren(children = []){
        if(!Array.isArray(children)){
            children = [children];
        }
        children.forEach(child => {
            if(child && child.element){
                this.element.appendChild(child.element);
            }
        });
        return this;
    }
}