import DomElement from "./DomElement.js";

export default class SelectElement extends DomElement {
    #options;
    
    constructor(tag, attributes = {}){
        super(tag, attributes);
        this.#options = [];
    }

    // Getter
    get options() {
        return this.#options;
    }

    // Setter
    set options(value) {
        this.#options = value;
    }

    createOptions(options){
        this.#options = options;
        if(this.element){
            options.forEach(optionData => {
                const option = document.createElement('option');
                if(Array.isArray(optionData) && optionData.length >= 2){
                    option.value = optionData[0];
                    option.textContent = optionData[1];
                } else if(typeof optionData === 'string'){
                    option.value = optionData;
                    option.textContent = optionData;
                }
                this.element.appendChild(option);
            });
        }
        return this;
    }

    createElement(){
        super.createElement();
        if(this.#options.length > 0){
            this.#options.forEach(optionData => {
                const option = document.createElement('option');
                if(Array.isArray(optionData) && optionData.length >= 2){
                    option.value = optionData[0];
                    option.textContent = optionData[1];
                } else if(typeof optionData === 'string'){
                    option.value = optionData;
                    option.textContent = optionData;
                }
                this.element.appendChild(option);
            });
        }
        return this;
    }
}