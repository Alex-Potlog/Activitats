export default class DomElement {
    #tag;
    #attributes;
    #element;

    constructor(tag, attributes = {}){
        this.#tag = tag;
        this.#attributes = attributes;
        this.#element = null;
    }

    // Getters
    get tag() {
        return this.#tag;
    }

    get attributes() {
        return this.#attributes;
    }

    get element() {
        return this.#element;
    }

    // Setters
    set element(value) {
        this.#element = value;
    }

    createElement(){
        this.#element = document.createElement(this.#tag);
        Object.entries(this.#attributes).forEach(([key, value]) => {
            this.#element.setAttribute(key, value);
        });
        return this;
    }

    printElement(position = {parentId: 'body', position: 'beforeend'}){
        if(!this.#element){
            console.error('Debe llamar a createElement() antes de printElement()');
            return this;
        }
        const parent = document.getElementById(position.parentId) || document.body;
        parent.insertAdjacentElement(position.position, this.#element);
        return this;
    }

    deleteElement(){
        if(this.#element && this.#element.parentNode){
            this.#element.parentNode.removeChild(this.#element);
        }
        this.#element = null;
    }

    addListener(actionFn, event){
        if(this.#element){
            this.#element.addEventListener(event, actionFn);
        }
    }

    removeListener(actionFn, event){
        if(this.#element){
            this.#element.removeEventListener(event, actionFn);
        }
    }
}