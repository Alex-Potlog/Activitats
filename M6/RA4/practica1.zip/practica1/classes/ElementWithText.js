import DomElement from "./DomElement.js";

export default class ElementWithText extends DomElement {
    #text;
    
    constructor(tag, attributes = {}){
        super(tag, attributes);
        this.#text = "";
    }

    // Getter
    get text() {
        return this.#text;
    }

    // Setter
    set text(value) {
        this.#text = value;
    }

    createElement(text = ""){
        super.createElement();
        this.#text = text;
        this.element.textContent = text;
        return this;
    }
}