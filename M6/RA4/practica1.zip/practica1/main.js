import ElementWithText from "./classes/ElementWithText.js";
import CompoundElement from "./classes/CompoundElement.js";
import SelectElement from "./classes/SelectElement.js";
import OnlyTagElement from "./classes/OnlyTagElement.js";

const formulari = new CompoundElement("form", {
        "id": "formulari",
        "method": "post",
        "action": "#"
    }).createElement().printElement({
        parentId: "body",
        position: "beforeend"
    });

function init() {
    const titol = new ElementWithText("h1", {
        "id": "titol"
    });

    titol.createElement("Crear personatge", { "id": "titol" }).printElement({
        parentId: "body",
        position: "beforebegin"
    });

    creaInputs(formulari);
    
    // Crear contenidor per les cards
    const cardsContainer = document.createElement("div");
    cardsContainer.id = "cards-container";
    document.body.appendChild(cardsContainer);
    
    // No carregar cards automàticament
}

function creaInputs(formulari){
    // Input 1

    const imgLabel = new ElementWithText("label", {
        "for": "imatge"
    }).createElement("Imatge: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    console.log(formulari)

    formulari.addChildren(imgLabel);
    

    const imatge = new OnlyTagElement("input", {
        "type": "file",
        "id": "imatge",
        "name": "imatge",
        "accept": "image/*"
    }).createElement("img").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(imatge);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Input 2
    const nomLabel = new ElementWithText("label", {
        "for": "nom"
    });
    nomLabel.createElement("Nom: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(nomLabel);

    const nom = new OnlyTagElement("input", {
        "type": "text",
        "id": "nom",
        "name": "nom"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(nom);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Input 3
    const descripcioLabel = new ElementWithText("label", {
        "for": "descripcio"
    });
    descripcioLabel.createElement("Descripció: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(descripcioLabel);

    const descripcio = new OnlyTagElement("textarea", {
        "id": "descripcio",
        "name": "descripcio",
        "rows": "4",
        "cols": "50"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(descripcio);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Input 4
    const origenLabel = new ElementWithText("label", {
        "for": "origen"
    });
    origenLabel.createElement("Origen: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(origenLabel);

    const origen = new OnlyTagElement("input", {
        "type": "text",
        "id": "origen",
        "name": "origen"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(origen);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Input 5
    const tipusLabel = new ElementWithText("label", {
        "for": "tipus"
    });
    tipusLabel.createElement("Tipus: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(tipusLabel);

    const tipus = new SelectElement("select", {
        "id": "tipus",
        "name": "tipus"
    });
    const opcionsT = [
        "Heroi",
        "Vilà",
        "Antiheroi"
    ];
    tipus.createOptions(opcionsT);
    tipus.createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(tipus);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Input 6
    const casaLabel = new ElementWithText("label", {
        "for": "casa"
    });
    casaLabel.createElement("Casa: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(casaLabel);

    const casa = new OnlyTagElement("input", {
        "type": "text",
        "id": "casa",
        "name": "casa"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(casa);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Input 7
    const estatLabel = new ElementWithText("label", {
        "for": "estat"
    });
    estatLabel.createElement("Estat: ").printElement({
        parentId: "formulari",
        position: "beforeend"
    });

    formulari.addChildren(estatLabel);

    const estat = new SelectElement("select", {
        "id": "estat",
        "name": "estat"
    });
    const opcions = [
        "Actiu",
        "Inactiu",
        "Retirat"
    ];
    estat.createOptions(opcions);
    estat.createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(estat);
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    // Butons
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    const saveButton = new OnlyTagElement("input", {
        "type": "submit",
        "value": "Guardar",
        "formaction": "cards.html"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(saveButton);

    const resetButton = new OnlyTagElement("input", {
        "type": "reset",
        "value": "Reiniciar"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    
    formulari.addChildren(resetButton);

    // Botons Load Cards i Delete Cards
    formulari.addChildren(new OnlyTagElement("br").createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    }));

    const loadButton = new OnlyTagElement("button", {
        "type": "button",
        "id": "loadCards"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    loadButton.element.textContent = "Load Cards";
    
    formulari.addChildren(loadButton);

    const deleteButton = new OnlyTagElement("button", {
        "type": "button",
        "id": "deleteCards"
    }).createElement().printElement({
        parentId: "formulari",
        position: "beforeend"
    });
    deleteButton.element.textContent = "Delete Cards";
    
    formulari.addChildren(deleteButton);

    // Event listeners
    document.getElementById("loadCards").addEventListener("click", loadCharacters);
    document.getElementById("deleteCards").addEventListener("click", deleteAllCards);

    document.getElementById("formulari").addEventListener("submit", function(event) {
        event.preventDefault();
        const formData = {
            nom: document.getElementById("nom").value,
            descripcio: document.getElementById("descripcio").value,
            origen: document.getElementById("origen").value,
            tipus: document.getElementById("tipus").value,
            casa: document.getElementById("casa").value,
            estat: document.getElementById("estat").value
        };
        
        const imatgeInput = document.getElementById("imatge");
        if (imatgeInput.files?.[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                formData.imatge = e.target.result;
                saveToLocalStorage(formData);
            };
            reader.readAsDataURL(imatgeInput.files[0]);
        } else {
            saveToLocalStorage(formData);
        }
    });
}

function saveToLocalStorage(formData) {
    let characters = JSON.parse(localStorage.getItem("characters")) || [];
    characters.push(formData);
    
    localStorage.setItem("characters", JSON.stringify(characters));
    
    alert("Personatge guardat!");
    
    document.getElementById("formulari").reset();
    
    // No actualitzar automàticament les cards
}

function loadCharacters() {
    const characters = JSON.parse(localStorage.getItem("characters")) || [];
    const container = document.getElementById("cards-container");
    
    if (!container) return;
    
    container.innerHTML = '';

    if (characters.length === 0) {
        return;
    }

    characters.forEach((character, index) => {
        const card = createCard(character, index);
        container.appendChild(card.element);
    });
}

function createCard(character, index) {
    const card = new CompoundElement("div", {
        "class": "character-card"
    }).createElement();

    // Imatge
    const imageContainer = new CompoundElement("div", {});
    if (character.imatge) {
        const img = new OnlyTagElement("img", {
            "src": character.imatge,
            "alt": character.nom || "Personatge",
            "class": "card-image"
        }).createElement();
        imageContainer.createElement().addChildren(img);
    } else {
        imageContainer.createElement();
        imageContainer.element.className = "card-image no-image";
        imageContainer.element.textContent = "Sense imatge";
    }
    card.addChildren(imageContainer);

    // Contingut
    const content = new CompoundElement("div", {
        "class": "card-content"
    }).createElement();

    // Camps
    const fields = [
        { key: "nom", label: "Nom", className: "card-nom" },
        { key: "descripcio", label: "Descripció", className: "card-descripcio" },
        { key: "origen", label: "Origen", className: "card-origen" },
        { key: "tipus", label: "Tipus", className: "card-tipus" },
        { key: "casa", label: "Casa", className: "card-casa" },
        { key: "estat", label: "Estat", className: "card-estat" }
    ];

    fields.forEach(field => {
        if (character[field.key]) {
            const fieldDiv = new CompoundElement("div", {
                "class": `card-field ${field.className}`
            }).createElement();

            const label = new ElementWithText("span", {
                "class": "card-label"
            }).createElement(field.label + ": ");

            const value = new ElementWithText("span", {
                "class": "card-value"
            }).createElement(character[field.key]);

            fieldDiv.addChildren([label, value]);
            content.addChildren(fieldDiv);
        }
    });

    card.addChildren(content);
    return card;
}

function deleteAllCards() {
    if (confirm("Segur que vols esborrar totes les cards?")) {
        localStorage.removeItem("characters");
        const container = document.getElementById("cards-container");
        if (container) {
            container.innerHTML = '';
        }
        alert("Totes les cards han estat esborrades!");
    }
}

init();